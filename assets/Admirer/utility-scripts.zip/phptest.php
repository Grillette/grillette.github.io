<?php
  echo("Just a test to see if PHP works.");
?>
